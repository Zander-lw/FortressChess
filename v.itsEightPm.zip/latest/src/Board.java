

import java.awt.*;

import javax.swing.*;


//import windowTest.Square;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class Board extends JFrame implements ActionListener

{
	int boardID;
	
	String lastButton;

	boolean cliked = false;
	
	PanelTest window;

	JFrame board;
	
	Square A1 = new Square("A1");
	Square A2 = new Square("A2");
	Square A3 = new Square("A3");
	Square A4 = new Square("A4");
	Square A5 = new Square("A5");
	Square A6 = new Square("A6");
	Square A7 = new Square("A7");
	Square A8 = new Square("A8");
	
	Square B1 = new Square("B1");
	Square B2 = new Square("B2");
	Square B3 = new Square("B3");
	Square B4 = new Square("B4");
	Square B5 = new Square("B5");
	Square B6 = new Square("B6");
	Square B7 = new Square("B7");
	Square B8 = new Square("B8");
	
	Square C1 = new Square("C1");
	Square C2 = new Square("C2");
	Square C3 = new Square("C3");
	Square C4 = new Square("C4");
	Square C5 = new Square("C5");
	Square C6 = new Square("C6");
	Square C7 = new Square("C7");
	Square C8 = new Square("C8");
	
	Square D1 = new Square("D1");
	Square D2 = new Square("D2");
	Square D3 = new Square("D3");
	Square D4 = new Square("D4");
	Square D5 = new Square("D5");
	Square D6 = new Square("D6");
	Square D7 = new Square("D7");
	Square D8 = new Square("D8");
	
	Square E1 = new Square("E1");
	Square E2 = new Square("E2");
	Square E3 = new Square("E3");
	Square E4 = new Square("E4");
	Square E5 = new Square("E5");
	Square E6 = new Square("E6");
	Square E7 = new Square("E7");
	Square E8 = new Square("E8");
	
	Square F1 = new Square("F1");
	Square F2 = new Square("F2");
	Square F3 = new Square("F3");
	Square F4 = new Square("F4");
	Square F5 = new Square("F5");
	Square F6 = new Square("F6");
	Square F7 = new Square("F7");
	Square F8 = new Square("F8");
	
	Square G1 = new Square("G1");
	Square G2 = new Square("G2");
	Square G3 = new Square("G3");
	Square G4 = new Square("G4");
	Square G5 = new Square("G5");
	Square G6 = new Square("G6");
	Square G7 = new Square("G7");
	Square G8 = new Square("G8");
	
	Square H1 = new Square("H1");
	Square H2 = new Square("H2");
	Square H3 = new Square("H3");
	Square H4 = new Square("H4");
	Square H5 = new Square("H5");
	Square H6 = new Square("H6");
	Square H7 = new Square("H7");
	Square H8 = new Square("H8");
	
	Square[] buttons = {A1,A2,A3,A4,A5,A6,A7,A8,B1,B2,B3,B4,B5,B6,B7,B8,C1,C2,C3,C4,C5,C6,C7,C8,D1,D2,D3,D4,D5,D6,D7,D8,E1,E2,E3,E4,E5,E6,E7,E8,F1,F2,F3,F4,F5,F6,F7,F8,G1,G2,G3,G4,G5,G6,G7,G8,H1,H2,H3,H4,H5,H6,H7,H8};

	/*
	//Toprow
	JButton A1 = new JButton();
	JButton A2 = new JButton();
	JButton A3 = new JButton();
	JButton A4 = new JButton();
	JButton A5 = new JButton();
	JButton A6 = new JButton();
	JButton A7 = new JButton();
	JButton A8 = new JButton();
	
	JButton B1 = new JButton();
	JButton B2 = new JButton();
	JButton B3 = new JButton();
	JButton B4 = new JButton();
	JButton B5 = new JButton();
	JButton B6 = new JButton();
	JButton B7 = new JButton();
	JButton B8 = new JButton();
	
	JButton C1 = new JButton();
	JButton C2 = new JButton();
	JButton C3 = new JButton();
	JButton C4 = new JButton();
	JButton C5 = new JButton();
	JButton C6 = new JButton();
	JButton C7 = new JButton();
	JButton C8 = new JButton();
	
	JButton D1 = new JButton();
	JButton D2 = new JButton();
	JButton D3 = new JButton();
	JButton D4 = new JButton();
	JButton D5 = new JButton();
	JButton D6 = new JButton();
	JButton D7 = new JButton();
	JButton D8 = new JButton();
	
	JButton E1 = new JButton();
	JButton E2 = new JButton();
	JButton E3 = new JButton();
	JButton E4 = new JButton();
	JButton E5 = new JButton();
	JButton E6 = new JButton();
	JButton E7 = new JButton();
	JButton E8 = new JButton();
	
	JButton F1 = new JButton();
	JButton F2 = new JButton();
	JButton F3 = new JButton();
	JButton F4 = new JButton();
	JButton F5 = new JButton();
	JButton F6 = new JButton();
	JButton F7 = new JButton();
	JButton F8 = new JButton();
	
	JButton G1 = new JButton();
	JButton G2 = new JButton();
	JButton G3 = new JButton();
	JButton G4 = new JButton();
	JButton G5 = new JButton();
	JButton G6 = new JButton();
	JButton G7 = new JButton();
	JButton G8 = new JButton();
	
	JButton H1 = new JButton();
	JButton H2 = new JButton();
	JButton H3 = new JButton();
	JButton H4 = new JButton();
	JButton H5 = new JButton();
	JButton H6 = new JButton();
	JButton H7 = new JButton();
	JButton H8 = new JButton();
	
	*/
	
	//========================================Highlight square method========================
	
	public void highLightSquare(String pos)
	{
		
		//System.out.println("Triggered=========================" + D1.getName()+ "compared to :                   "+ pos);
		for(int i = 0; i < buttons.length;i ++)
		{
			if(buttons[i].getName().equals(pos))
			{
				buttons[i].setOpaque(true);
				buttons[i].setVisible(true);
			}
		}
		
		
	}
	
			
	//=======================================================================================
	
	//==========================================Return Button name when pressed
	
	public boolean getClicked()
	{
		boolean temp = cliked;
		return temp;
	}
	
	public void setClicked(boolean x)
	{
		cliked = x;
	}
	
	public void recentButton(String name)
	{
		setClicked(true);
		lastButton = name;
		
		for(int i = 0; i < buttons.length;i ++)
		{
			buttons[i].setOpaque(false);
		}
	}
	
	public String getRecent()
	{
		return lastButton;
	}
	
	//==============================================================================
	Board()
	{

		
		
		
		board = new JFrame();
		
		window = new PanelTest();
		
		

		

		
		
		
		window.setLayout(new GridLayout(8,8,0,0));
		
		window.add(A1);
		window.add(A2);
		window.add(A3);
		window.add(A4);
		window.add(A5);
		window.add(A6);
		window.add(A7);
		window.add(A8);
		
		window.add(B1);
		window.add(B2);
		window.add(B3);
		window.add(B4);
		window.add(B5);
		window.add(B6);
		window.add(B7);
		window.add(B8);
		
		window.add(C1);
		window.add(C2);
		window.add(C3);
		window.add(C4);
		window.add(C5);
		window.add(C6);
		window.add(C7);
		window.add(C8);
		
		window.add(D1);
		window.add(D2);
		window.add(D3);
		window.add(D4);
		window.add(D5);
		window.add(D6);
		window.add(D7);
		window.add(D8);
		
		window.add(E1);
		window.add(E2);
		window.add(E3);
		window.add(E4);
		window.add(E5);
		window.add(E6);
		window.add(E7);
		window.add(E8);
		
		window.add(F1);
		window.add(F2);
		window.add(F3);
		window.add(F4);
		window.add(F5);
		window.add(F6);
		window.add(F7);
		window.add(F8);
		
		window.add(G1);
		window.add(G2);
		window.add(G3);
		window.add(G4);
		window.add(G5);
		window.add(G6);
		window.add(G7);
		window.add(G8);
		
		window.add(H1);
		window.add(H2);
		window.add(H3);
		window.add(H4);
		window.add(H5);
		window.add(H6);
		window.add(H7);
		window.add(H8);
		
		//A1.addActionListener(e -> e -> A1.returnSquare("A1"));	//add piece.move?
		
		/*
		 A1.addActionListener(e -> A1.returnSquare("A1"));			
		 
		A2.addActionListener(e -> A2.returnSquare("A2"));
		A3.addActionListener(e -> A3.returnSquare("A3"));
		A4.addActionListener(e -> A4.returnSquare("A4"));
		A5.addActionListener(e -> A5.returnSquare("A5"));
		A6.addActionListener(e -> A6.returnSquare("A6"));
		A7.addActionListener(e -> A7.returnSquare("A7"));
		A8.addActionListener(e -> A8.returnSquare("A8"));
		
		B1.addActionListener(e -> B1.returnSquare("B1"));
		B2.addActionListener(e -> B2.returnSquare("B2"));
		B3.addActionListener(e -> B3.returnSquare("B3"));
		B4.addActionListener(e -> B4.returnSquare("B4"));
		B5.addActionListener(e -> B5.returnSquare("B5"));
		B6.addActionListener(e -> B6.returnSquare("B6"));
		B7.addActionListener(e -> B7.returnSquare("B7"));
		B8.addActionListener(e -> B8.returnSquare("B8"));
		
		C1.addActionListener(e -> C1.returnSquare("C1"));
		C2.addActionListener(e -> C2.returnSquare("C2"));
		C3.addActionListener(e -> C3.returnSquare("C3"));
		C4.addActionListener(e -> C4.returnSquare("C4"));
		C5.addActionListener(e -> C5.returnSquare("C5"));
		C6.addActionListener(e -> C6.returnSquare("C6"));
		C7.addActionListener(e -> C7.returnSquare("C7"));
		C8.addActionListener(e -> C8.returnSquare("C8"));
		
		D1.addActionListener(e -> D1.returnSquare("D1"));
		D2.addActionListener(e -> D2.returnSquare("D2"));
		D3.addActionListener(e -> D3.returnSquare("D3"));
		D4.addActionListener(e -> D4.returnSquare("D4"));
		D5.addActionListener(e -> D5.returnSquare("D5"));
		D6.addActionListener(e -> D6.returnSquare("D6"));
		D7.addActionListener(e -> D7.returnSquare("D7"));
		D8.addActionListener(e -> D8.returnSquare("D8"));
	
		E1.addActionListener(e -> E1.returnSquare("E1"));
		E2.addActionListener(e -> E2.returnSquare("E2"));
		E3.addActionListener(e -> E3.returnSquare("E3"));
		E4.addActionListener(e -> E4.returnSquare("E4"));
		E5.addActionListener(e -> E5.returnSquare("E5"));
		E6.addActionListener(e -> E6.returnSquare("E6"));
		E7.addActionListener(e -> E7.returnSquare("E7"));
		E8.addActionListener(e -> E8.returnSquare("E8"));
	
		F1.addActionListener(e -> F1.returnSquare("F1"));
		F2.addActionListener(e -> F2.returnSquare("F2"));
		F3.addActionListener(e -> F3.returnSquare("F3"));
		F4.addActionListener(e -> F4.returnSquare("F4"));
		F5.addActionListener(e -> F5.returnSquare("F5"));
		F6.addActionListener(e -> F6.returnSquare("F6"));
		F7.addActionListener(e -> F7.returnSquare("F7"));
		F8.addActionListener(e -> F8.returnSquare("F8"));
		
		G1.addActionListener(e -> G1.returnSquare("G1"));
		G2.addActionListener(e -> G2.returnSquare("G2"));
		G3.addActionListener(e -> G3.returnSquare("G3"));
		G4.addActionListener(e -> G4.returnSquare("G4"));
		G5.addActionListener(e -> G5.returnSquare("G5"));
		G6.addActionListener(e -> G6.returnSquare("G6"));
		G7.addActionListener(e -> G7.returnSquare("G7"));
		G8.addActionListener(e -> G8.returnSquare("G8"));
		
		H1.addActionListener(e -> H1.returnSquare("H1"));
		H2.addActionListener(e -> H2.returnSquare("H2"));
		H3.addActionListener(e -> H3.returnSquare("H3"));
		H4.addActionListener(e -> H4.returnSquare("H4"));
		H5.addActionListener(e -> H5.returnSquare("H5"));
		H6.addActionListener(e -> H6.returnSquare("H6"));
		H7.addActionListener(e -> H7.returnSquare("H7"));
		H8.addActionListener(e -> H8.returnSquare("H8"));
		*/
		A1.addActionListener(e -> recentButton("A1"));	
		//A1.addActionListener(e -> System.out.println(A1.isOccupied));
		int[] x = {100,100};
		A2.addActionListener(e -> recentButton("A2"));
		A3.addActionListener(e -> recentButton("A3"));
		A4.addActionListener(e -> recentButton("A4"));
		A5.addActionListener(e -> recentButton("A5"));
		A6.addActionListener(e -> recentButton("A6"));
		A7.addActionListener(e -> recentButton("A7"));
		A8.addActionListener(e -> recentButton("A8"));
		
		B1.addActionListener(e -> recentButton("B1"));
		B2.addActionListener(e -> recentButton("B2"));
		B3.addActionListener(e -> recentButton("B3"));
		B4.addActionListener(e -> recentButton("B4"));
		B5.addActionListener(e -> recentButton("B5"));
		B6.addActionListener(e -> recentButton("B6"));
		B7.addActionListener(e -> recentButton("B7"));
		B8.addActionListener(e -> recentButton("B8"));
		
		
		
		C1.addActionListener(e -> recentButton("C1"));
		C2.addActionListener(e -> recentButton("C2"));
		C3.addActionListener(e -> recentButton("C3"));
		C4.addActionListener(e -> recentButton("C4"));
		C5.addActionListener(e -> recentButton("C5"));
		C6.addActionListener(e -> recentButton("C6"));
		C7.addActionListener(e -> recentButton("C7"));
		C8.addActionListener(e -> recentButton("C8"));;
		
		D1.addActionListener(e -> recentButton("D1"));
		D2.addActionListener(e -> recentButton("D2"));
		D3.addActionListener(e -> recentButton("D3"));
		D4.addActionListener(e -> recentButton("D4"));
		D5.addActionListener(e -> recentButton("D5"));
		D6.addActionListener(e -> recentButton("D6"));
		D7.addActionListener(e -> recentButton("D7"));
		D8.addActionListener(e -> recentButton("D8"));
	
		E1.addActionListener(e -> recentButton("E1"));
		E2.addActionListener(e -> recentButton("E2"));
		E3.addActionListener(e -> recentButton("E3"));
		E4.addActionListener(e -> recentButton("E4"));
		E5.addActionListener(e -> recentButton("E5"));
		E6.addActionListener(e -> recentButton("E6"));
		E7.addActionListener(e -> recentButton("E7"));
		E8.addActionListener(e -> recentButton("E8"));
	
		F1.addActionListener(e -> recentButton("F1"));
		F2.addActionListener(e -> recentButton("F2"));
		F3.addActionListener(e -> recentButton("F3"));
		F4.addActionListener(e -> recentButton("F4"));
		F5.addActionListener(e -> recentButton("F5"));
		F6.addActionListener(e -> recentButton("F6"));
		F7.addActionListener(e -> recentButton("F7"));
		F8.addActionListener(e -> recentButton("F8"));
		
		G1.addActionListener(e -> recentButton("G1"));
		G2.addActionListener(e -> recentButton("G2"));
		G3.addActionListener(e -> recentButton("G3"));
		G4.addActionListener(e -> recentButton("G4"));
		G5.addActionListener(e -> recentButton("G5"));
		G6.addActionListener(e -> recentButton("G6"));
		G7.addActionListener(e -> recentButton("G7"));
		G8.addActionListener(e -> recentButton("G8"));
		
		H1.addActionListener(e -> recentButton("H1"));
		H2.addActionListener(e -> recentButton("H2"));
		H3.addActionListener(e -> recentButton("H3"));
		H4.addActionListener(e -> recentButton("H4"));
		H5.addActionListener(e -> recentButton("H5"));
		H6.addActionListener(e -> recentButton("H6"));
		H7.addActionListener(e -> recentButton("H7"));
		H8.addActionListener(e -> recentButton("H8"));
		/*
		A1.setName("A1");
		A2.setName("A2");
		A3.setName("A3");
		A4.setName("A4");
		A5.setName("A5");
		A6.setName("A6");
		A7.setName("A7");
		A8.setName("A8");
		
		B1.setName("B1");
		B2.setName("B2");
		B3.setName("B3");
		B4.setName("B4");
		B5.setName("B5");
		B6.setName("B6");
		B7.setName("B7");
		B8.setName("B8");
		
		C1.setName("C1");
		C2.setName("C2");
		C3.setName("C3");
		C4.setName("C4");
		C5.setName("C5");
		C6.setName("C6");
		C7.setName("C7");
		C8.setName("C8");
	
		D1.setName("D1");
		D2.setName("D2");
		D3.setName("D3");
		D4.setName("D4");
		D5.setName("D5");
		D6.setName("D6");
		D7.setName("D7");
		D8.setName("D8");
	
		E1.setName("E1");
		E2.setName("E2");
		E3.setName("E3");
		E4.setName("E4");
		E5.setName("E5");
		E6.setName("E6");
		E7.setName("E7");
		E8.setName("E8");
	
		F1.setName("F1");
		F2.setName("F2");
		F3.setName("F3");
		F4.setName("F4");
		F5.setName("F5");
		F6.setName("F6");
		F7.setName("F7");
		F8.setName("F8");
		
		G1.setName("G1");
		G2.setName("G2");
		G3.setName("G3");
		G4.setName("G4");
		G5.setName("G5");
		G6.setName("G6");
		G7.setName("G7");
		G8.setName("G8");
		
		H1.setName("H1");
		H2.setName("H2");
		H3.setName("H3");
		H4.setName("H4");
		H5.setName("H5");
		H6.setName("H6");
		H7.setName("H7");
		H8.setName("H8");
		*/
		
		//A1.addActionListener(this);
		
		A1.setOpaque(false);
		A2.setOpaque(false);
		A3.setOpaque(false);
		A4.setOpaque(false);
		A5.setOpaque(false);
		A6.setOpaque(false);
		A7.setOpaque(false);
		A8.setOpaque(false);
		
		B1.setOpaque(false);
		B2.setOpaque(false);
		B3.setOpaque(false);
		B4.setOpaque(false);
		B5.setOpaque(false);
		B6.setOpaque(false);
		B7.setOpaque(false);
		B8.setOpaque(false);
		
		C1.setOpaque(false);
		C2.setOpaque(false);
		C3.setOpaque(false);
		C4.setOpaque(false);
		C5.setOpaque(false);
		C6.setOpaque(false);
		C7.setOpaque(false);
		C8.setOpaque(false);
		
		D1.setOpaque(false);
		D2.setOpaque(false);
		D3.setOpaque(false);
		D4.setOpaque(false);
		D5.setOpaque(false);
		D6.setOpaque(false);
		D7.setOpaque(false);
		D8.setOpaque(false);
	
		E1.setOpaque(false);
		E2.setOpaque(false);
		E3.setOpaque(false);
		E4.setOpaque(false);
		E5.setOpaque(false);
		E6.setOpaque(false);
		E7.setOpaque(false);
		E8.setOpaque(false);
	
		F1.setOpaque(false);
		F2.setOpaque(false);
		F3.setOpaque(false);
		F4.setOpaque(false);
		F5.setOpaque(false);
		F6.setOpaque(false);
		F7.setOpaque(false);
		F8.setOpaque(false);
		
		G1.setOpaque(false);
		G2.setOpaque(false);
		G3.setOpaque(false);
		G4.setOpaque(false);
		G5.setOpaque(false);
		G6.setOpaque(false);
		G7.setOpaque(false);
		G8.setOpaque(false);
		
		H1.setOpaque(false);
		H2.setOpaque(false);
		H3.setOpaque(false);
		H4.setOpaque(false);
		H5.setOpaque(false);
		H6.setOpaque(false);
		H7.setOpaque(false);
		H8.setOpaque(false);

		


		
		this.add(window);
		this.setSize(256,256);
		//this.setLocationRelativeTo(null);
		
		//Watch watch = new Watch();
		
		//this.add(timer.Timer());
		
		//this.pack();
		this.setVisible(true);
			
	}
	@Override
	public void actionPerformed(ActionEvent e) 
	{

	}
	
	
	
}
//assign each square to have a name, as string, or instead 
