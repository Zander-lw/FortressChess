
public class Player {

	
	public int Score = 0;
	public int Score2 = 0;
	
	public int getNum() 
	{
		return Score;
	}
	public void setNum(int Points) {
	    this.Score = Points;
	}
	public int getNum2() 
	{
		return Score2;
	}
	public void setNum2(int Point2) {
	    this.Score2 = Point2;
	}
	
	
	
	
}
