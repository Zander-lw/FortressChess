package windowTest;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Square extends JButton implements ActionListener
{

	int Xcoord;
	int Ycoord;
	
	boolean isOccupied = false;
	boolean isVictorySquare = false;
	
	
	Square()
	{

			;
		
	}
	/*
	public String getPieceColor()
	{
		if (Piece.color == "White")
			return "White;"
		else
			return "Black";
	}
	*/
	public boolean isOccupied()
	{
		if (this.isOccupied == true)
			return true;
		else
			return false;
	}
	
	public int getXPos()
	{
		return Xcoord;
	}
	
	public int getYPos()
	{
		return Ycoord;
	}
	
	public void setXPos(int Xin)
	{	
		this.Xcoord = Xin; 
	}
	
	public void setYPos(int Yin)
	{
		this.Ycoord = Yin;
	}
	
	public boolean getVictorySquare()
	{
		return isVictorySquare;
	}
	
	public void setVictrySquare(boolean isVictory)
	{
		this.isVictorySquare = isVictory;
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
	
		
		
	}

	
	
	
}
