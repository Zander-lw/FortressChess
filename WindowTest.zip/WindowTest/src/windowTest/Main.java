package windowTest;

public class Main 

{
	
    public static void main(String[] args) 
    {
    	Square A1 = new Square();

    	
        new Board();
       
        
        
    }
	
}
