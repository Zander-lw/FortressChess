package windowTest;

public class Board {

}
