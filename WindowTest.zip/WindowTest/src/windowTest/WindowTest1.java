package windowTest;

import java.awt.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class WindowTest1 extends JFrame implements ActionListener
{
	int boardID;
	
	

	
	PanelTest window;

	JFrame board;
	
	Square A1 = new Square();
	JButton A2 = new JButton();
	JButton A3 = new JButton();
	JButton A4 = new JButton();
	JButton A5 = new JButton();
	JButton A6 = new JButton();
	JButton A7 = new JButton();
	JButton A8 = new JButton();
	
	JButton B1 = new JButton();
	JButton B2 = new JButton();
	JButton B3 = new JButton();
	JButton B4 = new JButton();
	JButton B5 = new JButton();
	JButton B6 = new JButton();
	JButton B7 = new JButton();
	JButton B8 = new JButton();
	
	JButton C1 = new JButton();
	JButton C2 = new JButton();
	JButton C3 = new JButton();
	JButton C4 = new JButton();
	JButton C5 = new JButton();
	JButton C6 = new JButton();
	JButton C7 = new JButton();
	JButton C8 = new JButton();
	
	JButton D1 = new JButton();
	JButton D2 = new JButton();
	JButton D3 = new JButton();
	JButton D4 = new JButton();
	JButton D5 = new JButton();
	JButton D6 = new JButton();
	JButton D7 = new JButton();
	JButton D8 = new JButton();
	
	JButton E1 = new JButton();
	JButton E2 = new JButton();
	JButton E3 = new JButton();
	JButton E4 = new JButton();
	JButton E5 = new JButton();
	JButton E6 = new JButton();
	JButton E7 = new JButton();
	JButton E8 = new JButton();
	
	JButton F1 = new JButton();
	JButton F2 = new JButton();
	JButton F3 = new JButton();
	JButton F4 = new JButton();
	JButton F5 = new JButton();
	JButton F6 = new JButton();
	JButton F7 = new JButton();
	JButton F8 = new JButton();
	
	JButton G1 = new JButton();
	JButton G2 = new JButton();
	JButton G3 = new JButton();
	JButton G4 = new JButton();
	JButton G5 = new JButton();
	JButton G6 = new JButton();
	JButton G7 = new JButton();
	JButton G8 = new JButton();
	
	JButton H1 = new JButton();
	JButton H2 = new JButton();
	JButton H3 = new JButton();
	JButton H4 = new JButton();
	JButton H5 = new JButton();
	JButton H6 = new JButton();
	JButton H7 = new JButton();
	JButton H8 = new JButton();
	
	
	
	WindowTest1()
	{

		board = new JFrame();
		window = new PanelTest();
		window.setLayout(new GridLayout(8,8,0,0));
		
		window.add(A1);
		window.add(A2);
		window.add(A3);
		window.add(A4);
		window.add(A5);
		window.add(A6);
		window.add(A7);
		window.add(A8);
		
		window.add(B1);
		window.add(B2);
		window.add(B3);
		window.add(B4);
		window.add(B5);
		window.add(B6);
		window.add(B7);
		window.add(B8);
		
		window.add(C1);
		window.add(C2);
		window.add(C3);
		window.add(C4);
		window.add(C5);
		window.add(C6);
		window.add(C7);
		window.add(C8);
		
		window.add(D1);
		window.add(D2);
		window.add(D3);
		window.add(D4);
		window.add(D5);
		window.add(D6);
		window.add(D7);
		window.add(D8);
		
		window.add(E1);
		window.add(E2);
		window.add(E3);
		window.add(E4);
		window.add(E5);
		window.add(E6);
		window.add(E7);
		window.add(E8);
		
		window.add(F1);
		window.add(F2);
		window.add(F3);
		window.add(F4);
		window.add(F5);
		window.add(F6);
		window.add(F7);
		window.add(F8);
		
		window.add(G1);
		window.add(G2);
		window.add(G3);
		window.add(G4);
		window.add(G5);
		window.add(G6);
		window.add(G7);
		window.add(G8);
		
		window.add(H1);
		window.add(H2);
		window.add(H3);
		window.add(H4);
		window.add(H5);
		window.add(H6);
		window.add(H7);
		window.add(H8);
		
		A1.addActionListener(e -> System.out.println("Click!"));	//add piece.move?
		//A1.addActionListener(e -> System.out.println(A1.isOccupied));
		
		A2.addActionListener(e -> System.out.println("Click!"));
		A3.addActionListener(e -> System.out.println("Click!"));
		A4.addActionListener(e -> System.out.println("Click!"));
		A5.addActionListener(e -> System.out.println("Click!"));
		A6.addActionListener(e -> System.out.println("Click!"));
		A7.addActionListener(e -> System.out.println("Click!"));
		A8.addActionListener(e -> System.out.println("Click!"));
		
		B1.addActionListener(e -> System.out.println("Click!"));
		B2.addActionListener(e -> System.out.println("Click!"));
		B3.addActionListener(e -> System.out.println("Click!"));
		B4.addActionListener(e -> System.out.println("Click!"));
		B5.addActionListener(e -> System.out.println("Click!"));
		B6.addActionListener(e -> System.out.println("Click!"));
		B7.addActionListener(e -> System.out.println("Click!"));
		B8.addActionListener(e -> System.out.println("Click!"));
		
		C1.addActionListener(e -> System.out.println("Click!"));
		C2.addActionListener(e -> System.out.println("Click!"));
		C3.addActionListener(e -> System.out.println("Click!"));
		C4.addActionListener(e -> System.out.println("Click!"));
		C5.addActionListener(e -> System.out.println("Click!"));
		C6.addActionListener(e -> System.out.println("Click!"));
		C7.addActionListener(e -> System.out.println("Click!"));
		C8.addActionListener(e -> System.out.println("Click!"));
		
		D1.addActionListener(e -> System.out.println("Click!"));
		D2.addActionListener(e -> System.out.println("Click!"));
		D3.addActionListener(e -> System.out.println("Click!"));
		D4.addActionListener(e -> System.out.println("Click!"));
		D5.addActionListener(e -> System.out.println("Click!"));
		D6.addActionListener(e -> System.out.println("Click!"));
		D7.addActionListener(e -> System.out.println("Click!"));
		D8.addActionListener(e -> System.out.println("Click!"));
	
		E1.addActionListener(e -> System.out.println("Click!"));
		E2.addActionListener(e -> System.out.println("Click!"));
		E3.addActionListener(e -> System.out.println("Click!"));
		E4.addActionListener(e -> System.out.println("Click!"));
		E5.addActionListener(e -> System.out.println("Click!"));
		E6.addActionListener(e -> System.out.println("Click!"));
		E7.addActionListener(e -> System.out.println("Click!"));
		E8.addActionListener(e -> System.out.println("Click!"));
	
		F1.addActionListener(e -> System.out.println("Click!"));
		F2.addActionListener(e -> System.out.println("Click!"));
		F3.addActionListener(e -> System.out.println("Click!"));
		F4.addActionListener(e -> System.out.println("Click!"));
		F5.addActionListener(e -> System.out.println("Click!"));
		F6.addActionListener(e -> System.out.println("Click!"));
		F7.addActionListener(e -> System.out.println("Click!"));
		F8.addActionListener(e -> System.out.println("Click!"));
		
		G1.addActionListener(e -> System.out.println("Click!"));
		G2.addActionListener(e -> System.out.println("Click!"));
		G3.addActionListener(e -> System.out.println("Click!"));
		G4.addActionListener(e -> System.out.println("Click!"));
		G5.addActionListener(e -> System.out.println("Click!"));
		G6.addActionListener(e -> System.out.println("Click!"));
		G7.addActionListener(e -> System.out.println("Click!"));
		G8.addActionListener(e -> System.out.println("Click!"));
		
		H1.addActionListener(e -> System.out.println("Click!"));
		H2.addActionListener(e -> System.out.println("Click!"));
		H3.addActionListener(e -> System.out.println("Click!"));
		H4.addActionListener(e -> System.out.println("Click!"));
		H5.addActionListener(e -> System.out.println("Click!"));
		H6.addActionListener(e -> System.out.println("Click!"));
		H7.addActionListener(e -> System.out.println("Click!"));
		H8.addActionListener(e -> System.out.println("Click!"));
	
		A1.setOpaque(false);
		A2.setOpaque(false);
		A3.setOpaque(false);
		A4.setOpaque(false);
		A5.setOpaque(false);
		A6.setOpaque(false);
		A7.setOpaque(false);
		A8.setOpaque(false);
		
		B1.setOpaque(false);
		B2.setOpaque(false);
		B3.setOpaque(false);
		B4.setOpaque(false);
		B5.setOpaque(false);
		B6.setOpaque(false);
		B7.setOpaque(false);
		B8.setOpaque(false);
		
		C1.setOpaque(false);
		C2.setOpaque(false);
		C3.setOpaque(false);
		C4.setOpaque(false);
		C5.setOpaque(false);
		C6.setOpaque(false);
		C7.setOpaque(false);
		C8.setOpaque(false);
		
		D1.setOpaque(false);
		D2.setOpaque(false);
		D3.setOpaque(false);
		D4.setOpaque(false);
		D5.setOpaque(false);
		D6.setOpaque(false);
		D7.setOpaque(false);
		D8.setOpaque(false);
	
		E1.setOpaque(false);
		E2.setOpaque(false);
		E3.setOpaque(false);
		E4.setOpaque(false);
		E5.setOpaque(false);
		E6.setOpaque(false);
		E7.setOpaque(false);
		E8.setOpaque(false);
	
		F1.setOpaque(false);
		F2.setOpaque(false);
		F3.setOpaque(false);
		F4.setOpaque(false);
		F5.setOpaque(false);
		F6.setOpaque(false);
		F7.setOpaque(false);
		F8.setOpaque(false);
		
		G1.setOpaque(false);
		G2.setOpaque(false);
		G3.setOpaque(false);
		G4.setOpaque(false);
		G5.setOpaque(false);
		G6.setOpaque(false);
		G7.setOpaque(false);
		G8.setOpaque(false);
		
		H1.setOpaque(false);
		H2.setOpaque(false);
		H3.setOpaque(false);
		H4.setOpaque(false);
		H5.setOpaque(false);
		H6.setOpaque(false);
		H7.setOpaque(false);
		H8.setOpaque(false);

		
		this.add(window);
		this.pack();
		this.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	

}

//to add: timer, win condition, board type?
