package com.mycompany.csproject1;
public class test
{
  public static void main(String args[])
  {  
    new Menu().drawMenu();
  }
}  
