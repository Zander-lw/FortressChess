package com.mycompany.csproject1;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Menu extends Frame implements ActionListener
{
  private int boardID, turnTime, winChoice;
  private JFrame menu;
  private JPanel menuDisplay;
  private SettingsDisplay settingsDisplay;
  private ChooseBoardDisplay boardDisplay;
  private GridBagConstraints c;
  private JButton boardSelect, start, settings;
  public Menu()
  {
    boardID = 0;
    turnTime = 120;
    winChoice = 1;
    menu = new JFrame();
    menuDisplay = new JPanel();
    settingsDisplay = new SettingsDisplay(this);
    boardDisplay = new ChooseBoardDisplay(this);
    menu.setSize(1440,810);
    menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    boardSelect = new JButton("                                                BoardSelect", new ImageIcon("bOne.png"));
    start = new JButton("Start");
    settings = new JButton (new ImageIcon("settings.png"));
    start.setBackground(Color.GREEN);
    boardSelect.addActionListener(this);
    start.addActionListener(this);
    settings.addActionListener(this);
    menuDisplay.setLayout(new GridBagLayout());
    c = new GridBagConstraints();
    c.fill = GridBagConstraints.BOTH;
    c.gridx = 1;
    c.gridy = 1;
    c.weightx = 1;
    c.weighty = 1;
    menuDisplay.add(settings, c);
    c.gridx = 0;
    c.weightx = 2;
    c.weighty = 2;
    menuDisplay.add(boardSelect, c);
    c.gridy = 0;
    c.weightx = 3;
    c.weighty = 3;
    c.gridwidth = 2;
    menuDisplay.add(start, c);
    }
    
  public void drawMenu()
  {
      menu.setVisible(false);
      menu.setTitle("Main Menu");
      menu.setContentPane(menuDisplay);
      menu.setVisible(true);
  }
  public void startGame()
  {
      //drawBoard(boardID, turnTime, winChoice)
  }
  public void setWin(int choice) {winChoice = choice;}
  public void setTime(int time){turnTime = time;}
  public void setBoardID(int num){boardID = num;}
  public void actionPerformed(ActionEvent e)
  {
    if (e.getSource() == start)
    {
        startGame();
    }
    else if (e.getSource() == settings)
    {
      menu.setVisible(false);
      menu.setTitle("Settings");
      menu.setContentPane(settingsDisplay);     
      menu.setVisible(true);
    }
    else if (e.getSource() == boardSelect)
    {
      menu.setVisible(false);
      menu.setTitle("Board Select");
      menu.setContentPane(boardDisplay);     
      menu.setVisible(true);
    }
  }
}
