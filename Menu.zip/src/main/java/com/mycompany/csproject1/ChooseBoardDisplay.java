package com.mycompany.csproject1;

import java.awt.GridLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;


public class ChooseBoardDisplay extends javax.swing.JPanel
{
    private JButton b1,b2,b3,b4;
    Menu currentMenu;
    public ChooseBoardDisplay(Menu menu)
    {
      currentMenu = menu;
      b1 = new JButton(new ImageIcon("bOne.png"));      
      b2 = new JButton(new ImageIcon("bOne.png"));
      b3 = new JButton(new ImageIcon("bOne.png"));
      b4 = new JButton(new ImageIcon("bOne.png"));
      b1.addActionListener(new java.awt.event.ActionListener() {public void actionPerformed(java.awt.event.ActionEvent evt) {b1ActionPerformed(evt);}});
      b2.addActionListener(new java.awt.event.ActionListener() {public void actionPerformed(java.awt.event.ActionEvent evt) {b2ActionPerformed(evt);}});      
      b3.addActionListener(new java.awt.event.ActionListener() {public void actionPerformed(java.awt.event.ActionEvent evt) {b3ActionPerformed(evt);}});      
      b4.addActionListener(new java.awt.event.ActionListener() {public void actionPerformed(java.awt.event.ActionEvent evt) {b4ActionPerformed(evt);}});
      setLayout(new GridLayout(2,2));
      add(b1);
      add(b2);
      add(b3);
      add(b4);
    }
    private void b1ActionPerformed(java.awt.event.ActionEvent evt)
    {
        currentMenu.setBoardID(0);
        currentMenu.remove(this);
        currentMenu.drawMenu(); 
    }
    private void b2ActionPerformed(java.awt.event.ActionEvent evt)
    {
        currentMenu.setBoardID(1);
        currentMenu.remove(this);
        currentMenu.drawMenu();
    }
    private void b3ActionPerformed(java.awt.event.ActionEvent evt)
    {
        currentMenu.setBoardID(2);
        currentMenu.remove(this);
        currentMenu.drawMenu();
    }
    private void b4ActionPerformed(java.awt.event.ActionEvent evt)
    {
        currentMenu.setBoardID(3);
        currentMenu.remove(this);
        currentMenu.drawMenu();
    }
}
